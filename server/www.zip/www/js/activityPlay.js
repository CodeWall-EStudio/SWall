(function(){

    angular.module('activityPlay', [
        'ts.services.user',
        'ts.services.activity',
        'ap.controllers.main',
        'ap.controllers.videoUploader'
    ]);
})();